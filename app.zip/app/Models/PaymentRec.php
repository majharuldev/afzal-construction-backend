<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PaymentRec extends Model
{
    protected $guarded=[''];
}
