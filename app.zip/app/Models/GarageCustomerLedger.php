<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GarageCustomerLedger extends Model
{
      protected $guarded=[''];
}
