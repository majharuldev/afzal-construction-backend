<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PriceRate extends Model
{
    protected $guarded=[''];
}
